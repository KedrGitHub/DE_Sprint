# Название вакансии
# Требуемый опыт работы
# Заработную плату
# Регион

# Cntrl+/
import time
import random
import json
import tqdm
from email import header
from bs4 import BeautifulSoup
import requests as req

url = (
    "https://novosibirsk.hh.ru/search/vacancy?text=python+разработчик&salary=&clusters=true&ored_clusters=true&enable_snippets=true"
    "&enable_snippets=true"
)
headers = {"User-Agent": "Mozilla/5.0", "Host": "novosibirsk.hh.ru"}

#result = list()
data = {
    "data":[]
}


for page in  tqdm.tqdm(range(1, 200)):
    pageurl = f"{url}&page={page}"
    #print(pageurl)

    resp = req.get(pageurl, headers=headers)
    soup = BeautifulSoup(resp.text, "lxml")
    # выбираем блоки с наименованием python разраб
    tags = soup.find_all(class_="vacancy-serp-item-body")
    
    if len(tags)==0:  # Подстраховка на случай если страниц будет меньше указанного в range
        break
    # проходимся по блокам, 
    for tag in tqdm.tqdm(tags):
        # заголовок вакансии
        try:
            vacancy = tag.find(attrs={"data-qa": "serp-item__title"})
            if vacancy is not None:
                vacancyval = vacancy.text
            #выбираем зарплату
            salary = tag.find(attrs={"data-qa": "vacancy-serp__vacancy-compensation"})
            if salary is not None:
                salaryval = salary.text.replace('\u202f', '').strip()
                salaryval = salaryval.replace('\u200e', '').strip()
            else:
                salaryval = 'не указан'

            #регион
            region = tag.find(attrs={"data-qa": "vacancy-serp__vacancy-address"})
            if region is not None:
                regionval = region.text
            else:
                regionval = 'не указан'

            # Идем на уровень глубже для извлечения требуемого опыта
            resp2 = req.get(vacancy.attrs["href"], headers=headers)
            soup2 = BeautifulSoup(resp2.text, "lxml")
            experience = soup2.find(attrs={"data-qa": "vacancy-experience"})

            if experience is not None:
                experienceval = experience.text
            else:
                experienceval = 'не указан'

            #print(data)
            data["data"].append({"title":vacancyval, "work experience":experienceval, "salary":salaryval, "region":regionval})
        except:
            print('skip vacancy')

        time.sleep(random.randint(1,4)) # обход блокировки постоянных запросов

with open("data.json","w") as file:
    json.dump(data, file, ensure_ascii=False)

    #'\u200e'